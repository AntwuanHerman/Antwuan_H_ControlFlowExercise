//: A UIKit based Playground for presenting user interface
  
import UIKit
import PlaygroundSupport

var collection: [String] = ["Action Figures", "Trading Cards", "Rocks", "Legos", "Comic Books", "Vinyl Records", "Video Games", "Art Pieces", "Harry Potter Books", "Glasses"  ]
print("My collection contains \(collection.count) items.")
  collection.sort(by:<)
for item in collection {
     print(item)

    
}
